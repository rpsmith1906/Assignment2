from setuptools import setup

setup(
   name='spell',
   version='1.0',
   description='Spell Checker',
   author='Robert Smith',
   packages=['spell'],  
)
